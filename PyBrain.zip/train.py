import pickle

import random as r

fin = open("L_data_X", "rb")
X = pickle.load(fin)
r.shuffle(X)
fin.close()

fin = open("L_data_Y", "rb")
Y = pickle.load(fin)
r.shuffle(Y)
fin.close()

dic = {'L00': 0,
 'L01': 1,
 'L02': 2,
 'L03': 3,
 'L04': 4,
 'L05': 5,
 'L06': 6,
 'L07': 7,
 'L08': 8,
 'L11': 9,
 'L12': 10,
 'L13': 11,
 'L14': 12,
 'L15': 13,
 'L16': 14,
 'L17': 15,
 'L18': 16,
 'L21': 17,
 'L22': 18,
 'L23': 19,
 'L24': 20,
 'L25': 21,
 'L26': 22,
 'L27': 23,
 'L28': 24,
 'L29': 25,
 'L31': 26,
 'L32': 27,
 'L33': 28,
 'L34': 29,
 'L35': 30,
 'L36': 31,
 'L37': 32,
 'L38': 33
 }

inv_dic= {0: 'L00',
 1: 'L01',
 2: 'L02',
 3: 'L03',
 4: 'L04',
 5: 'L05',
 6: 'L06',
 7: 'L07',
 8: 'L08',
 9: 'L11',
 10: 'L12',
 11: 'L13',
 12: 'L14',
 13: 'L15',
 14: 'L16',
 15: 'L17',
 16: 'L18',
 17: 'L21',
 18: 'L22',
 19: 'L23',
 20: 'L24',
 21: 'L25',
 22: 'L26',
 23: 'L27',
 24: 'L28',
 25: 'L29',
 26: 'L31',
 27: 'L32',
 28: 'L33',
 29: 'L34',
 30: 'L35',
 31: 'L36',
 32: 'L37',
 33: 'L38'
 }

from pybrain.datasets            import ClassificationDataSet
from pybrain.utilities           import percentError
from pybrain.tools.shortcuts     import buildNetwork
from pybrain.supervised.trainers import BackpropTrainer
from pybrain.structure.modules   import SoftmaxLayer

from pylab import ion, ioff, figure, draw, contourf, clf, show, hold, plot
from scipy import diag, arange, meshgrid, where
from numpy.random import multivariate_normal
from numpy import random

total = len(X)
seg = int(0.8 * total)

alldata = ClassificationDataSet(200, 1, nb_classes=34)
for i in range(seg):
    alldata.addSample(X[i], dic[Y[i]])

trndata = alldata

tstdata = ClassificationDataSet(200, 1, nb_classes=34)
for i in range(seg, total):
    tstdata.addSample(X[i], dic[Y[i]])

trndata._convertToOneOfMany( )
tstdata._convertToOneOfMany( )

print ("Number of training patterns: ", len(trndata))
print ("Input and output dimensions: ", trndata.indim, trndata.outdim)
print ("First sample (input, target, class):")
print (trndata['input'][0], trndata['target'][0], trndata['class'][0])

fnn = buildNetwork( trndata.indim, 150, trndata.outdim)
trainer = BackpropTrainer( fnn, dataset=trndata, momentum=0.1, weightdecay=0.01, verbose=True)

fout = open("NN", "wb")
pickle.dump(fnn, fout)
fout.close()

for i in range(999999999999):
    print(i)
    trainer.trainEpochs( 1 )
    trnresult = percentError( trainer.testOnClassData(),
                              trndata['class'] )
    tstresult = percentError( trainer.testOnClassData(
           dataset=tstdata ), tstdata['class'] )

    print("epoch: %4d" % trainer.totalepochs, \
          "  train error: %5.2f%%" % trnresult, \
          "  test error: %5.2f%%" % tstresult)

    fout = open("NN", "wb")
    pickle.dump(fnn, fout)
    fout.close()

