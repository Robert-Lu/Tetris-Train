import pybrain

import pickle

inv_dic= {0: 'L00',
 1: 'L01',
 2: 'L02',
 3: 'L03',
 4: 'L04',
 5: 'L05',
 6: 'L06',
 7: 'L07',
 8: 'L08',
 9: 'L11',
 10: 'L12',
 11: 'L13',
 12: 'L14',
 13: 'L15',
 14: 'L16',
 15: 'L17',
 16: 'L18',
 17: 'L21',
 18: 'L22',
 19: 'L23',
 20: 'L24',
 21: 'L25',
 22: 'L26',
 23: 'L27',
 24: 'L28',
 25: 'L29',
 26: 'L31',
 27: 'L32',
 28: 'L33',
 29: 'L34',
 30: 'L35',
 31: 'L36',
 32: 'L37',
 33: 'L38'
 }

fnn = pickle.load(open("NN", "rb"))
X = pickle.load(open("L_data_X", "rb"))

def show_board(b):
    strbuf = ".______________________________.\n"
    for i in range(20):
        strbuf += "|"
        for j in range(10):
            if (b[i * 10 + j] == 1):
                strbuf += "[#]"
            else:
                strbuf += " . "
        strbuf += "|\n"
    strbuf += ".~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.\n"

    print(strbuf)


def max_index_of(lst):
    best = 0
    for i in range(len(lst)):
        if lst[i] > lst[best]:
            best = i

    return best


def test(b):
    show_board(b)
    res = max_index_of(fnn.activate(b))
    print("Result is " + inv_dic[res])


